# EBLG Dashboard (AVWX + AirLabs + OSM geofence + Noise)

## Déploiement sur Render (Front + Backend Node)

1. Créez un repo GitHub et poussez ce projet.
2. Sur https://render.com → **Create Web Service** :
   - Repository: votre repo
   - Branch: `main`
   - Environment: `Node`
   - Root Directory: `server`
   - Build Command: `npm install`
   - Start Command: `npm start`
3. Dans Render → *Environment Variables* :
   - `AVWX_TOKEN=...`
   - `AIRLABS_KEY=...`
   - `PORT=10000`
4. Ouvrez l’URL Render fournie.

### Endpoints API
- `/api/metar` `/api/taf`
- `/api/flights?scope=all|dep|arr|over`
- `/api/flight?flight_iata=...` (ou `flight_icao`, `hex`, `reg_number`)
- `/api/geofences` (OSM via Nominatim)
- `/api/noise/latest` `/api/noise/history`
- `POST /api/noise/ingest` `{ id, value, lat?, lon?, meta? }`
- `/api/alerts` et `POST /api/alerts/log`

## Dev local
```
cd server
cp .env.example .env
# renseignez vos clés AVWX / AIRLABS
npm install
npm start
```
Puis ouvrez http://localhost:8080
