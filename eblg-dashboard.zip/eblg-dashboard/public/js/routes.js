function destPoint(lat, lon, bearingDeg, distanceKm){
  const R = 6371;
  const brng = bearingDeg * Math.PI/180;
  const dR = distanceKm / R;
  const lat1 = lat * Math.PI/180;
  const lon1 = lon * Math.PI/180;
  const lat2 = Math.asin(Math.sin(lat1)*Math.cos(dR) + Math.cos(lat1)*Math.sin(dR)*Math.cos(brng));
  const lon2 = lon1 + Math.atan2(Math.sin(brng)*Math.sin(dR)*Math.cos(lat1), Math.cos(dR)-Math.sin(lat1)*Math.sin(lat2));
  return { lat: lat2*180/Math.PI, lon: lon2*180/Math.PI };
}

function drawCorridors(map){
  const layer = L.layerGroup().addTo(map);
  const c = CONFIG.corridors;
  const center = c.runway_center;

  // Départ (RWY 22 approximatif)
  const depEnd = destPoint(center.lat, center.lon, c.dep_bearing_deg, c.length_km);
  L.polyline([[center.lat, center.lon], [depEnd.lat, depEnd.lon]],
    { color:'#ff8c3a', weight:4, opacity:0.8 }).addTo(layer).bindPopup('Couloir Départ (RWY 22)');

  // Arrivée (RWY 04 approximatif)
  const arrStart = destPoint(center.lat, center.lon, c.arr_bearing_deg, c.length_km);
  L.polyline([[arrStart.lat, arrStart.lon], [center.lat, center.lon]],
    { color:'#3aa3ff', weight:4, opacity:0.8 }).addTo(layer).bindPopup('Couloir Arrivée (RWY 04)');

  // Lignes latérales
  const side = 2;
  const depLeft  = destPoint(center.lat, center.lon, c.dep_bearing_deg - side, c.length_km);
  const depRight = destPoint(center.lat, center.lon, c.dep_bearing_deg + side, c.length_km);
  L.polyline([[center.lat, center.lon], [depLeft.lat, depLeft.lon]],  { color:'#ff8c3a', weight:1.5, opacity:0.6, dashArray:'4 6' }).addTo(layer);
  L.polyline([[center.lat, center.lon], [depRight.lat, depRight.lon]], { color:'#ff8c3a', weight:1.5, opacity:0.6, dashArray:'4 6' }).addTo(layer);

  const arrLeft  = destPoint(center.lat, center.lon, c.arr_bearing_deg - side, c.length_km);
  const arrRight = destPoint(center.lat, center.lon, c.arr_bearing_deg + side, c.length_km);
  L.polyline([[arrLeft.lat, arrLeft.lon], [center.lat, center.lon]],  { color:'#3aa3ff', weight:1.5, opacity:0.6, dashArray:'4 6' }).addTo(layer);
  L.polyline([[arrRight.lat, arrRight.lon], [center.lat, center.lon]], { color:'#3aa3ff', weight:1.5, opacity:0.6, dashArray:'4 6' }).addTo(layer);

  return layer;
}
